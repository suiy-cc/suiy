var searchData=
[
  ['open',['open',['../d5/d03/structah__sink__api.html#ad1871cd376b581f25785b00c80326ec4',1,'ah_sink_api::open()'],['../dd/dad/structah__source__api.html#a7886e8154953fe30967081d2369cc969',1,'ah_source_api::open()']]]
];
