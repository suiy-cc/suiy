var searchData=
[
  ['channels',['channels',['../d8/d7a/structah__channel__map.html#a43af46f45fe861bbf39ef6ea1b2d88bc',1,'ah_channel_map::channels()'],['../d0/d15/structah__sample__spec.html#a43af46f45fe861bbf39ef6ea1b2d88bc',1,'ah_sample_spec::channels()']]],
  ['close',['close',['../d5/d03/structah__sink__api.html#a2f84ef3afbb6322b58f86272683862a4',1,'ah_sink_api::close()'],['../dd/dad/structah__source__api.html#ad0af6d8c00912e47e0c313ff22e5822d',1,'ah_source_api::close()']]]
];
