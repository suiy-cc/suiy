var searchData=
[
  ['pause',['pause',['../d5/d03/structah__sink__api.html#ac7f7702228bb9583291905b66dce5d63',1,'ah_sink_api::pause()'],['../dd/dad/structah__source__api.html#a1ee1346720e8fa5136184687f80f3014',1,'ah_source_api::pause()']]],
  ['prepare',['prepare',['../d5/d03/structah__sink__api.html#a558da59d741f7bd2bd0c714bb392d301',1,'ah_sink_api::prepare()'],['../dd/dad/structah__source__api.html#abeb281f48607805ba22570bcc6ed2b4f',1,'ah_source_api::prepare()']]]
];
